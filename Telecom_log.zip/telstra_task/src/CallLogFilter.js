import React, { useState, useEffect } from 'react';

const CallLogFilter = ({ callLogs }) => {
  const [callTypeFilter, setCallTypeFilter] = useState('all');
  const [callerNameFilter, setCallerNameFilter] = useState('');
  const [receiverNameFilter, setReceiverNameFilter] = useState('');
  const [filteredCallLogs, setFilteredCallLogs] = useState(callLogs);

  useEffect(() => {
    filterCallLogs();
  }, [callTypeFilter, callerNameFilter, receiverNameFilter]);

  const filterCallLogs = () => {
    const filteredLogs = callLogs.filter((log) => {
      const callTypeMatch = callTypeFilter === 'all' || log.callType === callTypeFilter;
      const callerNameMatch =
        callerNameFilter === '' || log.callerName.toLowerCase().includes(callerNameFilter.toLowerCase());
      const receiverNameMatch =
        receiverNameFilter === '' || log.receiverName.toLowerCase().includes(receiverNameFilter.toLowerCase());

      return callTypeMatch && callerNameMatch && receiverNameMatch;
    });

    setFilteredCallLogs(filteredLogs);
  };

  return (
    <div>
      <div>
        <label>Call Type:</label>
        <select value={callTypeFilter} onChange={(e) => setCallTypeFilter(e.target.value)}>
          <option value="all">All</option>
          <option value="incoming">Incoming</option>
          <option value="outgoing">Outgoing</option>
        </select>
      </div>
      <div>
        <label>Caller's Name:</label>
        <input
          type="text"
          value={callerNameFilter}
          onChange={(e) => setCallerNameFilter(e.target.value)}
        />
      </div>
      <div>
        <label>Receiver's Name:</label>
        <input
          type="text"
          value={receiverNameFilter}
          onChange={(e) => setReceiverNameFilter(e.target.value)}
        />
      </div>
      <ul>
        {filteredCallLogs.map((log, index) => (
          <li key={index}>
            Call Type: {log.callType}, Caller: {log.callerName}, Receiver: {log.receiverName}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CallLogFilter;
