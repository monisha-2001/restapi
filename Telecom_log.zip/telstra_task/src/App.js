import React from 'react';
import CallLogFilter from './CallLogFilter'; 

function App() {
  const callLogs = [
    {
      "id": 1,
      "callerName": "John Doe",
      "callerPhoneNumber": "123-456-7890",
      "receiverName": "Jane Smith",
      "receiverPhoneNumber": "987-654-3210",
      "duration": 10,
      "callType": "incoming",
      "timestamp": "2023-09-08T10:30:00Z"
    },
    {
      "id": 2,
      "callerName": "Alice Johnson",
      "callerPhoneNumber": "555-123-4567",
      "receiverName": "Bob Brown",
      "receiverPhoneNumber": "555-987-6543",
      "duration": 15,
      "callType": "outgoing",
      "timestamp": "2023-09-08T11:45:00Z"
    }

  ]
  

  return (
    <div className="App">
      <CallLogFilter callLogs={callLogs} />
    </div>
  );
}

export default App;
